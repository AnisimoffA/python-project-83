from flask import Flask, render_template, request, redirect, url_for, session
from datetime import date
from validator import url_validator
import psycopg2
import os


DATABASE_URL = os.getenv('DATABASE_URL')

#----------------database info opened------------------
def connect_db():
    conn = psycopg2.connect(DATABASE_URL)
    return conn

try:
    connection = psycopg2.connect(DATABASE_URL)
    connection.autocommit = True
    
    with connection.cursor() as cursor:
        cursor.execute(
            '''CREATE TABLE urls (
                    id bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
                    name varchar(255) UNIQUE,
                    created_at date);'''
                    )        
        print('[INFO]Запрос отработан')
        
except Exception as Ex:
    print('[INFO]Ошибка: ', Ex)
finally:
    if connection:
        connection.close()
        print('[INFO]Соединение закрыто')

#----------------database info closed------------------
app = Flask(__name__)
app.config['SECRET_KEY'] = '3G23G#$%VHH>&<.4U,83NKJ'


@app.route('/', methods=['POST', 'GET'])
def main_page():
    session.clear()
    if request.method == 'POST':
        URL = request.form['url']
        
        try:
            connection = connect_db()
            connection.autocommit = True
            
            with connection.cursor() as cursor:
                cursor.execute(
                    f'''INSERT INTO urls (name, created_at) VALUES ('{URL}', '{date.today()}');'''
                            )        
                print('[INFO]Запись добавлена')
                
            with connection.cursor() as cursor:
                cursor.execute(
                    f'''SELECT * FROM urls ORDER BY id DESC LIMIT 1;'''
                            )
                
                session['url_id'], session['url_name'], session['url_date'] = cursor.fetchone()
                print('[INFO]Данные выбраны')
                
        except Exception as Ex:
            #сюда надо впихнуть обработчик ошибки повторяющихся юрлок
            print('[INFO]Ошибка: ', Ex)
        finally:
            if connection:
                connection.close()
                print('[INFO]Соединение закрыто')
                
    if session:
        return redirect(url_for('link_page', id=session['url_id']))
    else:
        return render_template('index.html')

@app.route('/<id>')
def link_page(id):
    return render_template('link_page.html', url_id=session['url_id'], url_name=session['url_name'], url_date=session['url_date'])


if __name__ == "__main__":
    app.run(debug=True)








