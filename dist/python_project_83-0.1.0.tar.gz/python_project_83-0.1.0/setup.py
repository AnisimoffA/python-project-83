# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['page_analyzer']

package_data = \
{'': ['*']}

install_requires = \
['flask>=2.3.2,<3.0.0', 'gunicorn>=20.1.0,<21.0.0', 'pytest-cov>=4.1.0,<5.0.0']

setup_kwargs = {
    'name': 'python-project-83',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/AnisimoffA/python-project-83/workflows/hexlet-check/badge.svg)](https://github.com/AnisimoffA/python-project-83/actions)',
    'author': 'Anisimoff',
    'author_email': 'happyprooo@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
